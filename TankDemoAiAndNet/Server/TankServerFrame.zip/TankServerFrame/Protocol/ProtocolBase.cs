﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TankServerFrame.Protocol
{
    /// <summary>
    /// 协议基类
    /// </summary>
    public class ProtocolBase
    {
        /// <summary>
        /// 解码器，解码readbuff中从start开始的length字节readbuff，int start,int length
        /// </summary>
        /// <param name="readbuff">存从缓冲区中的字节流</param>
        /// <param name="start">解码开始位置</param>
        /// <param name="length">解码结束位置</param>
        /// <returns></returns>
        public virtual ProtocolBase Decode(byte[] readbuff,int start,int length)
        {
            return new ProtocolBase();
        }
        /// <summary>
        /// 编码器
        /// </summary>
        /// <returns></returns>
        public virtual byte[] Ecode()
        {
            return new byte[] { };
        }
        /// <summary>
        /// 协议的名称，用于消息分发
        /// </summary>
        /// <returns></returns>
        public virtual string GetName()
        {
            return "";
        }
        /// <summary>
        /// 描述
        /// </summary>
        /// <returns></returns>
        public virtual string GetDesc()
        {
            return "";
        }
    }
}
