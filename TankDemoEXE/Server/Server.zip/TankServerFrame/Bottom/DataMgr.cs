﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Data;
using System.Text.RegularExpressions;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace TankServerFrame
{
   /// <summary>
   /// 数据库管理类
   /// </summary>
   public class DataMgr
   {
       MySqlConnection sqlConn;

       //单例模式
       public static DataMgr instance;
       public DataMgr()
       {
            instance = this;
            Connect();  
        }
       /// <summary>
       /// 连接
       /// </summary>
       public void Connect()
       {
           //数据库
           string connStr = "Database=game;Data Source=127.0.0.1;";
           connStr += "User Id=root;Password=123456;port=3306";
           sqlConn = new MySqlConnection(connStr);
           try
           {
               sqlConn.Open();
           }
           catch (Exception e)
           {
               Console.WriteLine("[DataMgr]Connect " + e.Message);
               return;
           }
       }
       /// <summary>
       /// 判断安全字符串
       /// </summary>
       /// <param name="str"></param>
       /// <returns></returns>
       public bool IsSafeStr(String str)
       {
           return !Regex.IsMatch(str,@"[-|;|,|\/|\(|\)|\[|\]|\{|\}|\%|@|\*|!|\']");
       }
       /// <summary>
       /// 是否存在用户 
       /// 是不是可以注册
       /// </summary>
       /// <param name="id"></param>
       /// <returns></returns>
       private bool CanRegister(string id)
       {
           //防注入
           if (!IsSafeStr(id))
               return false;
           //查询id是否存在
           string cmdStr = string.Format("Select * from user where id='{0}';",id);
           MySqlCommand cmd = new MySqlCommand(cmdStr,sqlConn);
           try
           {
               MySqlDataReader dataReader = cmd.ExecuteReader();
               bool hasRows = dataReader.HasRows;
               dataReader.Close();
               return !hasRows;
           }
           catch (Exception e)
           {
               Console.WriteLine("[DataMgr]CanRegister fail"+e.Message);
               return false;
           }
       }
       /// <summary>
       /// 注册
       /// </summary>
       /// <param name="id"></param>
       /// <param name="pw"></param>
       /// <returns></returns>
       public bool Register(string id,string pw)
       {
           //防注入
           if(!IsSafeStr(id) || !IsSafeStr(pw))
           {
               Console.WriteLine("[DataMgr]Register 使用非法字符");
               return false;
           }
           //能否注册
           if(!CanRegister(id))
           {
               Console.WriteLine("[DataMgr]Register !Register");
               return false;
           }
           //写入数据库User表
           string cmdStr = string.Format("insert into user set id ='{0}',pw='{1}';",id,pw);
           MySqlCommand cmd = new MySqlCommand(cmdStr,sqlConn);
           try
           {
               cmd.ExecuteNonQuery();
               return true;
           }
           catch (Exception e)
           {
               Console.WriteLine("[DataMgr]Register "+e.Message);
               return false;
           }
       }
       /// <summary>
       /// 创建角色
       /// </summary>
       /// <param name="id"></param>
       /// <returns></returns>
       public bool CreatePlayer(string id)
       {
           //防注入
           if(!IsSafeStr(id))
           {
               return false;
           }
           //序列化
           IFormatter formatter = new BinaryFormatter();
           MemoryStream stream = new MemoryStream();
           PlayerData playData = new PlayerData();
           try
           {
               formatter.Serialize(stream,playData);
           }
           catch (Exception e)
           {
               Console.WriteLine("[DataMgr]CreatePlayer 序列化"+e.Message);
               return false;
           }
           byte[] byteArr = stream.ToArray();
           //写入数据库
           string cmdStr = string.Format("insert into player set id='{0}',data=@data",id);
           MySqlCommand cmd = new MySqlCommand(cmdStr,sqlConn);
           cmd.Parameters.Add("@data",MySqlDbType.Blob);
           cmd.Parameters[0].Value = byteArr;
           try
           {
               cmd.ExecuteNonQuery();
               return true;
           }
           catch (Exception e)
           {
               Console.WriteLine("[DataMgr]CreatePlayer写入 "+e.Message);
               return false;
           }
       }
       /// <summary>
       /// 检测用户名和密码
       /// </summary>
       /// <returns></returns>
       public bool CheckPassWord(string id,string pw)
       {
           //防sql注入
           if (!IsSafeStr(id) | !IsSafeStr(pw))
               return false;
           //查询
           string cmdStr = string.Format("select * from user where id='{0}' and pw='{1}'",id,pw);
           MySqlCommand cmd = new MySqlCommand(cmdStr,sqlConn);
           try
           {
               MySqlDataReader dataReader = cmd.ExecuteReader();
               bool hasRows = dataReader.HasRows;
               dataReader.Close();
               return hasRows;
           }
           catch (Exception e)
           {
               Console.WriteLine("[DataMgr]CheckPassword"+e.Message);
               return false;
           }
       }
       /// <summary>
       /// 获取玩家的数据
       /// </summary>
       /// <param name="id"></param>
       /// <returns></returns>
       public PlayerData GetPlayerData(string id)
       {
           PlayerData playerData = null;
           if (!IsSafeStr(id))
               return playerData;
           //查询
           string cmdStr = string.Format("Select * from player where id='{0}';",id);
           MySqlCommand cmd = new MySqlCommand(cmdStr,sqlConn);
           byte[] buffer;//bug
           try
           {
               MySqlDataReader dataReader = cmd.ExecuteReader();
               if(!dataReader.HasRows)
               {
                   dataReader.Close();
                   return playerData;
               }
               dataReader.Read();

               long len = dataReader.GetBytes(1,0,null,0,0);//1是data 0是id
               buffer = new byte[len];
               dataReader.GetBytes(1,0,buffer,0,(int)len);
               dataReader.Close();
           }
           catch (Exception e)
           {
               Console.WriteLine("[DataMgr]GetPlayerData 查询"+e.Message);
               //Console.WriteLine("" + e.Message);
               return playerData;
           }
           //反序列化
           MemoryStream stream = new MemoryStream(buffer);
           try
           {
               BinaryFormatter formatter = new BinaryFormatter();
               playerData = (PlayerData)formatter.Deserialize(stream);
               return playerData;
           }
           catch (Exception e)
           {
               Console.WriteLine("[DataMgr]GetPlayerData 反序列化"+e.Message);
               return playerData;
           }
       }
       /// <summary>
       /// 保存角色
       /// </summary>
       /// <param name="player"></param>
       /// <returns></returns>
       public bool SavePlayer(Player player)
       {
           string id = player.id;
           PlayerData playerData = player.data;
           //序列化
           IFormatter formatter  = new BinaryFormatter();
           MemoryStream stream = new MemoryStream();
           try
           {
               formatter.Serialize(stream,playerData);
           }
           catch (Exception e)
           {
               Console.WriteLine("[DataMgr]SavePlayer 序列化"+e.Message);
               return false;
           }
           byte[] byteArr = stream.ToArray();
           //写入数据库
           string formatStr = "Update player set data =@data where id='{0}';";//,Data=@data;
           string cmdStr = string.Format(formatStr,player.id);
           MySqlCommand cmd = new MySqlCommand(cmdStr,sqlConn);
           cmd.Parameters.Add("@data", MySqlDbType.Blob);
           cmd.Parameters[0].Value = byteArr;
           try
           {
               cmd.ExecuteNonQuery();
               return true;
           }
           catch (Exception e)
           {
               Console.WriteLine("[DataMgr]SavePlayer 写入" + e.Message);
               return false;
           }
       }
   }
}
