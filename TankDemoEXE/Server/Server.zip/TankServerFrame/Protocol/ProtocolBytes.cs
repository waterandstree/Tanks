﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TankServerFrame.Protocol
{
  
    public class ProtocolBytes:ProtocolBase
    {
        /// <summary>
        /// 传输的字节流
        /// </summary>
        public byte[] bytes;

        /// <summary>
        /// 字节流协议模型
        /// </summary>
        public override ProtocolBase Decode(byte[] readbuff, int start, int length)
        {
            ProtocolBytes protocol = new ProtocolBytes();
            protocol.bytes = new byte[length];
            Array.Copy(readbuff, start, protocol.bytes, 0, length);
            return protocol;
        }
        /// <summary>
        /// 字节流协议编码器
        /// </summary>
        /// <returns></returns>
        public override byte[] Ecode()
        {
            return bytes;
        }
        /// <summary>
        /// 字节流协议名称
        /// </summary>
        /// <returns></returns>
        public override string GetName()
        {
            return GetString(0);
        }
        /// <summary>
        /// 获取字节流的描述
        /// </summary>
        /// <returns></returns>
        public override string GetDesc()
        {
            string str = "";
            if (bytes == null) return str;
            for (int i = 0; i < bytes.Length; i++)
            {
                int b = (int)bytes[i];
                str += b.ToString() + " ";
            }
            return str;
        }
        /// <summary>
        /// 添加字符串
        /// </summary>
        /// <param name="str"></param>
        public void AddString(string str)
        {
            //获取字符串长度
            Int32 len = str.Length;
            //获取字符串长度的字节数组
            byte[] lenBytes = BitConverter.GetBytes(len);
            //将字符串转成字符数组
            byte[] strBytes = System.Text.Encoding.UTF8.GetBytes(str);
            if (bytes == null)
                bytes = lenBytes.Concat(strBytes).ToArray();//将字符串长度和字符串连接
            else
                bytes = bytes.Concat(lenBytes).Concat(strBytes).ToArray();//空字符串+长度
        }
        /// <summary>
        /// 从字节数据的Start 出开始读取字符串
        /// </summary>
        /// <returns></returns>
        public string GetString(int start,ref int end)
        {
            if (bytes == null) return "";
            if (bytes.Length < start + sizeof(Int32))
                return "";
            //字符串长度
            Int32 strLen = BitConverter.ToInt32(bytes,start);
            string str = System.Text.Encoding.UTF8.GetString(bytes,start+sizeof(Int32),strLen);
            end = start + sizeof(Int32) + strLen;
            return str;
        }
        /// <summary>
        /// 获取字符串
        /// </summary>
        /// <param name="start"></param>
        /// <returns></returns>
        public string GetString(int start)
        {
            int end = 0;
            return GetString(start, ref end);//end从值传递改引用传递
        }
        /// <summary>
        /// 整型转byte数组
        /// </summary>
        /// <param name="num"></param>
        public void AddInt(int num)
        {
            byte[] numBytes = BitConverter.GetBytes(num);
            if (bytes == null)
                bytes = numBytes;
            else
                bytes = bytes.Concat(numBytes).ToArray();
        }

        public int GetInt(int start,ref int end)
        {
            if (bytes == null)
                return 0;
            if (bytes.Length < start + sizeof(Int32))
                return 0;
            end = start + sizeof(Int32);
            return BitConverter.ToInt32(bytes,start);
        }

        public void AddFloat(float num)
        {
            byte[] numBytes = BitConverter.GetBytes(num);
            if (bytes == null)
                bytes = numBytes;
            else
                bytes = bytes.Concat(numBytes).ToArray();
        }

        public float GetFloat(int start,ref int end)
        {
            if (bytes == null)
                return 0;
            if (bytes.Length < start + sizeof(float))
                return 0;
            end = start + sizeof(float);
            return BitConverter.ToSingle(bytes,start);//float
        }

        public float GetFloat(int start)
        {
            int end = 0;
            return GetFloat(start,ref end);
        }

    }
}
