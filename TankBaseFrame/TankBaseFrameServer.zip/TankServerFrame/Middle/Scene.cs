﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TankServerFrame.Protocol;

namespace TankServerFrame.Middle
{
    /// <summary>
    /// 游戏场景
    /// </summary>
    public class Scene
    {
        //单例 这里只考虑一个场景
        public static Scene instance;
        public Scene()
        {
            instance = this;
        }


        List<ScenePlayer> list = new List<ScenePlayer>();

        /// <summary>
        /// 根据名字获取ScenePlayer
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ScenePlayer GetScenePlayer(string id)
        {
            for (int i = 0; i < list.Count; i++)
            {
                if (list[i].id == id)
                    return list[i];
            }
            return null;
        }
        /// <summary>
        /// 场景中添加玩家
        /// </summary>
        /// <param name="id"></param>
        public void AddPlayer(string id)
        {
            lock(list)
            {
                ScenePlayer p = new ScenePlayer();
                p.id = id;
                list.Add(p);
            }
        }
        /// <summary>
        /// 删除玩家
        /// </summary>
        /// <param name="id"></param>
        public void DelPlayer(string id)
        {
            lock(this)
            {
                ScenePlayer p =  GetScenePlayer(id);//bug
                if (p != null)
                    list.Remove(p);
            }

            ProtocolBytes protocol = new ProtocolBytes();
            protocol.AddString("PlayerLeave");
            protocol.AddString(id);
            ServNet.instance.Broadcast(protocol);
        }
        /// <summary>
        /// 发送玩家列表
        /// </summary>
        /// <param name="player"></param>
        public void SendPlayerList(Player player)
        {
            int count = list.Count;
            ProtocolBytes protocol = new ProtocolBytes();
            protocol.AddString("GetList");
            protocol.AddInt(count);
            for (int i = 0; i < count; i++)
            {
                ScenePlayer p = list[i];
                protocol.AddString(p.id);
                protocol.AddFloat(p.x);
                protocol.AddFloat(p.y);
                protocol.AddFloat(p.z);
                protocol.AddInt(p.score);
            }
            player.Send(protocol);
        }
        /// <summary>
        /// 更新信息
        /// </summary>
        /// <param name="id"></param>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <param name="z"></param>
        /// <param name="score"></param>
        public void UpdateInfo(string id,float x,float y,float z,int score)
        {
            int count = list.Count;
            ProtocolBytes protocol = new ProtocolBytes();

            ScenePlayer p = GetScenePlayer(id);
            if(p == null)
            {
                return;
            }
            p.x = x;
            p.y = y;
            p.z = z;
            p.score = score;
        }
    }
}
