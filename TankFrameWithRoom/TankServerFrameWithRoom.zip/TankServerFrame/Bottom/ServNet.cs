﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using TankServerFrame.Protocol;
using TankServerFrame.Logic;
using System.Reflection;

namespace TankServerFrame
{
    public class ServNet
    {
        //监听套接字
        public Socket listenfd;
        //客户端的连接
        public Conn[] conns;
        //最大连接数
        public int maxConn = 50;
        //单例
        public static ServNet instance;
        //主定时器
        private System.Timers.Timer timer = new System.Timers.Timer(1000);
        //心跳时间
        public long heartBeatTimer = 180;//180
        //协议
        public ProtocolBase proto;
        //消息的派发
        public HandleConnMsg handleConnMsg = new HandleConnMsg();
        public HandlePlayerMsg handlePlayerMsg = new HandlePlayerMsg();
        public HandlePlayerEvent handlePlayerEvent = new HandlePlayerEvent();
        //public HandleRoomMsg handleRoomMsg = new HandleRoomMsg();

        public ServNet()
        {
            instance = this;
        }
        /// <summary>
        /// 客户端连接池索引，返回负数表示获取失败
        /// </summary>
        /// <returns></returns>
        public int NextIndex()
        {
            if (conns == null)
                return -1;
            for (int i = 0; i < conns.Length; i++)
            {
                if (conns[i] == null)
                {
                    conns[i] = new Conn();
                    return i;
                }
                else if (conns[i].isUse == false)
                {
                    return i;
                }

            }
            return -1;
        }
        /// <summary>
        /// 开启服务器
        /// </summary>
        /// <param name="host"></param>
        /// <param name="port"></param>
        public void Start(string host, int port)
        {
            //定时器 Elapsed消逝
            timer.Elapsed += new System.Timers.ElapsedEventHandler(HandleMainTimer);
            timer.AutoReset = false;
            timer.Enabled = true;

            //连接池
            conns = new Conn[maxConn];
            for (int i = 0; i < maxConn; i++)
            {
                conns[i] = new Conn();
            }
            //Socket
            listenfd = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            //Bind
            IPAddress ip = IPAddress.Parse(host);
            IPEndPoint ipEp = new IPEndPoint(ip, port);
            listenfd.Bind(ipEp);
            //Listen
            listenfd.Listen(maxConn);
            //Accept
            listenfd.BeginAccept(AcceptCb, null);
            Console.WriteLine("服务器开启成功");
        }
        /// <summary>
        /// 接收回调
        /// </summary>
        /// <param name="ar"></param>
        public void AcceptCb(IAsyncResult ar)
        {
            try
            {
                Socket socket = listenfd.EndAccept(ar);
                int index = NextIndex();

                if (index < 0)
                {
                    socket.Close();
                    Console.WriteLine("[警告]连接已满");
                }
                else
                {
                    Conn conn = conns[index];
                    conn.Init(socket);
                    string adr = conn.GetAdress();
                    Console.WriteLine("客户端连接 [" + adr + "] conn池ID:" + index);
                    conn.socket.BeginReceive(conn.readBuff, conn.buffCount, conn.BuffRemain(), SocketFlags.None, ReceiveCb, conn);
                    listenfd.BeginAccept(AcceptCb, null);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Accept失败:" + e.Message);
            }
        }

        public void ReceiveCb(IAsyncResult ar)
        {
            Conn conn = (Conn)ar.AsyncState;
            try
            {
                int count = conn.socket.EndReceive(ar);
                //关闭信号
                if (count <= 0)
                {
                    Console.WriteLine("收到 [" + conn.GetAdress() + "] 断开连接");
                    conn.Close();
                    return;
                }
                conn.buffCount += count;
                ProcessData(conn);
                conn.socket.BeginReceive(conn.readBuff, conn.buffCount, conn.BuffRemain(), SocketFlags.None, ReceiveCb, conn);//bug
            }
            catch (Exception e)
            {
                Console.WriteLine("收到 [" + conn.GetAdress() + "] 断开连接");
                conn.Close();
            }
        }
        /// <summary>
        /// 黏包分包处理
        /// </summary>
        /// <param name="conn"></param>
        private void ProcessData(Conn conn)
        {
            //小于长度字节
            if (conn.buffCount < sizeof(Int32))
            {
                Console.WriteLine("消息长度不合理");
                return;
            }
            //消息长度
            Array.Copy(conn.readBuff, conn.lenBytes, sizeof(Int32));
            conn.msgLength = BitConverter.ToInt32(conn.lenBytes, 0);
            Console.WriteLine("消息长度" + conn.msgLength);
            if (conn.buffCount < conn.msgLength + sizeof(Int32))
            {
                Console.WriteLine("消息长度不规范");
                return;
            }
            //处理消息-----引入协议
            ProtocolBase protocol = proto.Decode(conn.readBuff, sizeof(Int32), conn.msgLength);
            HandleMsg(conn,protocol);
            //清除已处理的消息
            int count = conn.buffCount - conn.msgLength - sizeof(Int32);
            Array.Copy(conn.readBuff, sizeof(Int32) + conn.msgLength, conn.readBuff, 0, count);
            conn.buffCount = count;
            if (conn.buffCount > 0)
            {
                ProcessData(conn);
            }
        }
        /// <summary>
        /// 处理消息
        /// </summary>
        /// <param name="conn">连接的客户端</param>
        /// <param name="protoBase">协议</param>
        private void HandleMsg(Conn conn, ProtocolBase protoBase)
        {
            string name = protoBase.GetName();
            Console.WriteLine("[收到协议]" + name);
            string methodName = "Msg" + name;
            //连接协议分发
            if(conn.player == null || name == "HeatBeat" || name == "Logout")
            {
                MethodInfo mm = handleConnMsg.GetType().GetMethod(methodName);//通过实例提取类中的指定的方法
                if(mm == null)
                {
                    string str = "[警告]HandleMsg没有处理连接方法";
                    Console.WriteLine(str + methodName);
                    return;
                }
                Object[] obj = new object[] { conn, protoBase };
                Console.WriteLine("[处理连接消息]"+conn.GetAdress()+":"+name);
                mm.Invoke(handleConnMsg,obj);//方法调用 实例+参数
            }
                //角色协议分发
            else 
            {
                MethodInfo mm = handlePlayerMsg.GetType().GetMethod(methodName);
                if(mm == null)
                {
                    string str = "[警告]HandleMsg没有处理连接方法";
                    Console.WriteLine(str + methodName);
                    return;
                }
                object[] obj = new object[] { conn.player, protoBase };
                Console.WriteLine("[处理玩家消息]"+conn.player.id + ":"+name);
                mm.Invoke(handlePlayerMsg,obj);
            }
        }

        /// <summary>
        /// 发送
        /// </summary>
        /// <param name="conn"></param>
        /// <param name="str"></param>
        public void Send(Conn conn,ProtocolBase protocol)
        {
            //将消息长度和消息的内容都装换成byte[]
            byte[] bytes = protocol.Ecode();
            byte[] length = BitConverter.GetBytes(bytes.Length);
            byte[] sendbuff = length.Concat(bytes).ToArray();
            try 
	        {
                conn.socket.BeginSend(sendbuff, 0, sendbuff.Length, SocketFlags.None, null, null);//bug
	        }
	        catch (Exception e)
	        {
                Console.WriteLine("[发送消息]"+conn.GetAdress()+":"+e.Message);
	        }

        }
        /// <summary>
        /// 广播
        /// </summary>
        /// <param name="protocol"></param>
        public void Broadcast(ProtocolBase protocol)
        {
            for (int i = 0; i < conns.Length; i++)
            {
                if (!conns[i].isUse)
                    continue;
                if (conns[i].player == null)
                    continue;
                Send(conns[i],protocol);
            }
        }

        /// <summary>
        /// 关闭客户端
        /// </summary>
        public void Close()
        {
            for (int i = 0; i < conns.Length; i++)
            {
                Conn conn = conns[i];
                if (conn == null) continue;
                if (!conn.isUse) continue;
                lock (conn)
                {
                    conn.Close();
                }
            }
        }

        /// <summary>
        /// 主定时器
        ///     发送心跳信号
        ///     触发
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void HandleMainTimer(Object sender,System.Timers.ElapsedEventArgs e)
        {
            //处理心跳
            HeartBeat();
            timer.Start();
        }

        /// <summary>
        /// 心跳
        /// </summary>
        public void HeartBeat()
        {
            //Console.WriteLine("[主定时器执行]");
            long timeNow = Sys.GetTimeStamp();

            for (int i = 0; i < conns.Length; i++)
            {
                Conn conn = conns[i];
                if (conn == null) continue;
                if (!conn.isUse) continue;

                if(conn.lastTickTime < timeNow - heartBeatTimer)
                {
                    Console.WriteLine("[心跳引起断开连接]"+conn.GetAdress());
                    lock (conn)
                    {
                        conn.Close();
                    }
                }
            }
        }
        /// <summary>
        /// 打印信息
        /// </summary>
        public void Print()
        {
            Console.WriteLine("===服务器登入消息===");
            for (int i = 0; i < conns.Length; i++)
            {
                if (conns[i] == null)
                    continue;
                if (!conns[i].isUse)
                    continue;
                string str = "连接[" + conns[i].GetAdress() + "]";
                if(conns[i].player != null)
                {
                    str += "玩家id" + conns[i].player.id;
                }
                Console.WriteLine(str);
            }
        }
    }
}
