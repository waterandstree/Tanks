﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TankServerFrame.Protocol
{
    /// <summary>
    /// 字符串协议模型
    /// </summary>
    public class ProtocolStr:ProtocolBase
    {
        /// <summary>
        /// 传输字符串
        /// </summary>
        public string str;

        /// <summary>
        /// 字符串解码器
        /// </summary>
        /// <param name="readbuff"></param>
        /// <param name="start"></param>
        /// <param name="length"></param>
        /// <returns></returns>
        public override ProtocolBase Decode(byte[] readbuff, int start, int length)
        {
            ProtocolStr protocol = new ProtocolStr();
            protocol.str = System.Text.Encoding.UTF8.GetString(readbuff,start,length);
            return (ProtocolBase)protocol;
        }
        /// <summary>
        /// 字符串编码器
        /// </summary>
        /// <returns></returns>
        public override byte[] Ecode()
        {
            byte[] b = System.Text.Encoding.UTF8.GetBytes(str);
            return b;
        }
        /// <summary>
        /// 获取协议名称
        /// </summary>
        /// <returns></returns>
        public override string GetName()
        {
            if (str.Length == 0) return "";
            return str.Split(',')[0];
        }
        /// <summary>
        /// 获取协议的描述
        /// </summary>
        /// <returns></returns>
        public override string GetDesc()
        {
            return str;
        }
    }
}
