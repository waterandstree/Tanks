﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TankServerFrame.Middle
{
    /// <summary>
    /// 场景中角色信息
    /// </summary>
    public class ScenePlayer
    {
        public string id;
        public float x = 0;
        public float y = 0;
        public float z = 0;
        public int score = 0;
    }
}
