﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TankServerFrame.Protocol;

namespace TankServerFrame
{
    public class RoomMgr
    {
        /// <summary>
        /// 单例
        /// </summary>

        public static RoomMgr instance;
        public RoomMgr()
        {
            instance = this;
        }
        /// <summary>
        /// 房间列表
        /// </summary>
        public List<Room> list = new List<Room>();
        /// <summary>
        /// 创建房间
        /// </summary>
        /// <param name="player"></param>
        public void CreateRoom(Player player)
        {
            Room room = new Room();
            lock(list)
            {
                list.Add(room);
                room.AddPlayer(player);//创建房间同时把自己加进去
            }
        }
        /// <summary>
        /// 玩家离开
        /// </summary>
        /// <param name="player"></param>
        public void LeaveRoom(Player player)
        {
            //离开玩家对象的房间
            PlayerTempData tempdata = player.tempData;
            //玩家不在房间中
            if (tempdata.status == PlayerTempData.Status.None)
                return;
            Room room = tempdata.room;
            lock(list)
            {
                room.DelPlayer(player.id);
                if (room.list.Count == 0)
                    list.Remove(room);
            }
        }

        /// <summary>
        /// 输出房间列表
        /// </summary>
        /// <returns></returns>
        public ProtocolBytes GetRoomList()
        {
            ProtocolBytes protocol = new ProtocolBytes();
            protocol.AddString("GetRoomList");
            int count = list.Count;
            //房间数量
            protocol.AddInt(count);
            //每个房间的信息
            for (int i = 0; i < count; i++)
            {
                Room room = list[i];
                protocol.AddInt(room.list.Count);
                protocol.AddInt((int)room.status);
            }
            return protocol;
        }

    }
}
